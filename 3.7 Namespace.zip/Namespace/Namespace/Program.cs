﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Namespace
{ 
    class Program
    {
        static void Main(string[] args)
        {
            var doc = XDocument.Load("Orders.xml");

            Console.WriteLine(doc.Declaration.Version);
            Console.WriteLine(doc.Declaration.Encoding);
            Seperator();

            Console.WriteLine(doc.Root.Name);

            //var orderNamespace = (XNamespace) "http://yourcompany.com/order";
            XNamespace orderNamespace = "http://yourcompany.com/order";
            XNamespace itemNamespace = "http://yourcompany.com/item";

            var order = doc.Element(orderNamespace + "Order");

            Console.WriteLine(order.Name);

            Seperator();

            // Show all descendants
            Console.WriteLine("Show All Descendants");
            foreach (var element in order.Descendants())
            {
                Console.WriteLine(element.Name);

            }

            Seperator();

            // Show all Item Id Element Values
            Console.WriteLine("Show Item Id Element Values");
            foreach (var element in order.Descendants(itemNamespace + "Id"))
            {
                Console.WriteLine($"Name: {element.Name}, Value: {element.Value}");

            }

            Console.ReadLine();
        }

        private static void Seperator ()
        {
            Console.WriteLine("*******************");
        }


        
    }
}
