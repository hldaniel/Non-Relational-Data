﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Orders
{
	class Program
	{
		static void Main(string[] args)
		{
			var doc = XDocument.Load("orders.xml");

			Console.WriteLine(doc.Declaration.Version);
			Console.WriteLine(doc.Declaration.Encoding);
			Seperator();

			Console.WriteLine(doc.Root.Name);

			var order = doc.Element("Order");
			Console.WriteLine(order.Name);

			var root = new XElement("Order",
				new XElement("ID", "10023"),
				new XElement("OrderDate", "04/27/2017"),
				new XElement("Items",
					new XElement("Item",
						new XElement("ID", 1),
						new XElement("Quantity",
							new XAttribute("unit", "Each"), "2")
							)

				)
			);
			root.Save("Created.xml");




			Console.ReadLine();
		}
		private static void Seperator()
		{
			Console.WriteLine("****************");
		}
	}
}
