﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//include
using System.Web.Script.Serialization;
using System.IO;

namespace NEWExample
{
    class Book
    {
        public string Name { get; set; }
        public string Genre { get; set; }
        public int Year { get; set; }

        public override string ToString ()
        {
            return string.Format("Name: {0} \nGenre: {1} \nYear: {2}", Name, Genre, Year);
        }


    }
    class Program
    {
        static void Main(string[] args)
        {
            //deserialize JSON from file
            String JSONstring = File.ReadAllText("JSON.json");

            JavaScriptSerializer ser = new JavaScriptSerializer();
            Book b1 = ser.Deserialize<Book>(JSONstring);
            Console.WriteLine(b1);

            

            //output JSON file

            Book b2 = new Book() { Name = "book2", Genre = "Romance", Year = 1999 };
            string outputJSON = ser.Serialize(b2);
            File.WriteAllText("Output.json", outputJSON);



        }
    }
}
